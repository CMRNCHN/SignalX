# SignalX frontend

**This folder is the single source of truth for all UI.** Vite, Tauri, Replit, and Figma handoff all read from here — do not put React/CSS under a root `src/` again.

## What's in here

| Path | Role |
|------|------|
| `src/App.tsx` | Shell, nav, panels (Messages, Catalog, Orders, Sales, Outbox, Settings…) |
| `src/ProfileRail.tsx` | 4th column on Messages |
| `src/DeviceLinkQr.tsx` | QR for device link |
| `src/navIcons.tsx` | Nav SVGs |
| `src/styles.css` | Design tokens + layout |
| `src/api.ts` | Typed Tauri IPC client |
| `src/api.mock.ts` | Browser/Replit fixtures when Tauri is missing |
| `FIGMA.md` | Screens, tokens, file map for design AI |
| `vite.config.ts` | Vite (also used from repo root) |

## Run locally (repo root)

```bash
# from SignalX/
npm install
npm run frontend:dev    # http://localhost:5173 — mock API banner in browser
./run-dev.sh            # Tauri desktop + live Signal IPC
```

## Replit / share with another AI

1. Prefer uploading **only this folder**, or run `npm run frontend:pack` at repo root → `SignalX-frontend.zip`.
2. In Replit: import the zip/folder, then:

```bash
npm install
npm run dev
```

3. You should see **Browser preview (mock API)** — UI works; Signal send/receive does not.
4. Do **not** edit `src-tauri/` or Rust from the frontend AI session unless asked.

Standalone scripts live in this folder's `package.json` (deps mirror the monorepo).

## Figma

See [FIGMA.md](./FIGMA.md). Point design tools at `styles.css` tokens and the screen list there.

## Rules for frontend collaborators

- Edit files **only** under `frontend/`.
- Keep Tauri commands behind `api.ts` — don't call `invoke` from components.
- Mock data goes in `api.mock.ts`; keep types in sync with `api.ts`.
- After UI changes that need desktop verification, the operator runs `./run-dev.sh`.
