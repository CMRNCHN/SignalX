# SignalX UI — Figma / design map

Use this with Figma Make, code-to-design, or a design AI. Implementation lives entirely under `frontend/src/`.

## Visual direction

- Dark flat-gray modular shell (floated panels, liquid-glass composer).
- Fonts (loaded in `index.html`): IBM Plex Sans / Mono / Serif.
- Tokens in `src/styles.css` `:root`:

| Token | Value | Use |
|-------|-------|-----|
| `--bg` | `#222326` | App background |
| `--bg-lift` | `#2a2b2f` | Lifted surfaces |
| `--panel` | `#2c2e33` | Panels |
| `--border` | `rgba(255,255,255,0.1)` | Dividers |
| `--text` | `#f0f2f5` | Primary text |
| `--text-dim` | `#9aa0a8` | Secondary |
| `--accent-cta` | `#3d8bfd` | Primary actions |
| `--danger` / `--warn` / `--ok` | red / amber / green | Status |
| `--bubble-in` / `--bubble-out` | `#3a3d44` / `#1e3a5f` | Chat bubbles |
| `--radius` | `16px` | Large corners |
| `--glass` | translucent panel | Composer / glass |

Avoid purple gradients, cream/serif broadsheet looks, or heavy glow clusters — match the existing shell.

## Screens (nav)

1. **Messages** (`threads`) — 3–4 columns: rail | thread list | conversation | optional `ProfileRail`
2. **Search** — message search results
3. **Contacts** / **Groups** — local meta lists
4. **Catalog** (`products`) — inventory, stock adjust, CSV, low-stock filter
5. **Customers** — commerce customers
6. **Orders** — quotes/drafts + lifecycle
7. **Sales** — period summary, top products, commerce audit
8. **Outbox** — queued / failed outbound
9. **Auto-reply log** (`audit`)
10. **Settings** — tabs: System | Device link | IVR | Auto-reply

## File ownership

| File | Owns |
|------|------|
| `App.tsx` | Shell grid, all panels, settings, composer |
| `ProfileRail.tsx` | Standing, notes, AI actions, ledger, quote chip |
| `DeviceLinkQr.tsx` | QR rendering for link URI |
| `navIcons.tsx` | Sidebar icons |
| `styles.css` | Layout + tokens |
| `api.ts` / `api.mock.ts` | Data only — not visual |

## Export tips

- Prefer full-shell frames at ~1100×720 (Tauri default window).
- Messages with profile rail: wider (~1280+) or hide rail below 1100px (see CSS).
- Browser mock banner is preview-only; omit from Figma production frames.
