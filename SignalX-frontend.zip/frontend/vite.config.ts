import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const dir = path.dirname(fileURLToPath(import.meta.url));
const monorepo = fs.existsSync(path.resolve(dir, "../src-tauri"));

// Canonical frontend Vite config — used from repo root and standalone (Replit).
export default defineConfig({
  root: dir,
  plugins: [react()],
  clearScreen: false,
  server: {
    port: 5173,
    strictPort: true,
    host: true,
  },
  envPrefix: ["VITE_", "TAURI_"],
  build: {
    // Monorepo/Tauri: repo-root dist/. Standalone Replit: frontend/dist/.
    outDir: path.resolve(dir, monorepo ? "../dist" : "dist"),
    emptyOutDir: true,
    target: "esnext",
  },
});
