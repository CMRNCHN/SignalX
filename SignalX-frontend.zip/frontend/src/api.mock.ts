/** Browser / Replit fixtures when Tauri IPC is unavailable. */

import type { UnlistenFn } from "@tauri-apps/api/event";
import type {
  AiStatus,
  ApiResult,
  AutoReplyAuditEntry,
  AutoReplySettings,
  CommerceAuditEvent,
  ContactMeta,
  Customer,
  Diagnostics,
  GroupMeta,
  IvrMenus,
  IvrSettings,
  Message,
  Order,
  OutboxItem,
  OutboxSummary,
  Product,
  ReceiveLoopState,
  SalesSummary,
  SearchResult,
  ThreadIvrStatus,
  ThreadSummary,
} from "./api";

export function isTauriRuntime(): boolean {
  if (typeof window === "undefined") return false;
  const w = window as Window & {
    __TAURI_INTERNALS__?: unknown;
    __TAURI__?: unknown;
  };
  return Boolean(w.__TAURI_INTERNALS__ || w.__TAURI__);
}

const NOW = Date.now();
const THREAD_A = "+15716902864";
const THREAD_B = "+16175550123";

const mockThreads: ThreadSummary[] = [
  {
    id: THREAD_A,
    participants: [THREAD_A],
    last_message_timestamp: NOW - 60_000,
    unread_count: 1,
    message_count: 3,
    outbox_count: 0,
  },
  {
    id: THREAD_B,
    participants: [THREAD_B],
    last_message_timestamp: NOW - 3600_000,
    unread_count: 0,
    message_count: 2,
    outbox_count: 0,
  },
];

const mockMessages: Record<string, Message[]> = {
  [THREAD_A]: [
    {
      id: "m1",
      thread_id: THREAD_A,
      timestamp: NOW - 120_000,
      sender: THREAD_A,
      content: "Hey — do you still have the sampler pack?",
      direction: "Incoming",
    },
    {
      id: "m2",
      thread_id: THREAD_A,
      timestamp: NOW - 90_000,
      sender: "me",
      recipient: THREAD_A,
      content: "Yes! Want a quote?",
      direction: "Outgoing",
    },
    {
      id: "m3",
      thread_id: THREAD_A,
      timestamp: NOW - 60_000,
      sender: THREAD_A,
      content: "Please send one.",
      direction: "Incoming",
    },
  ],
  [THREAD_B]: [
    {
      id: "m4",
      thread_id: THREAD_B,
      timestamp: NOW - 7200_000,
      sender: THREAD_B,
      content: "Thanks for the invoice.",
      direction: "Incoming",
    },
    {
      id: "m5",
      thread_id: THREAD_B,
      timestamp: NOW - 3600_000,
      sender: "me",
      recipient: THREAD_B,
      content: "Anytime!",
      direction: "Outgoing",
    },
  ],
};

const mockProducts: Product[] = [
  {
    id: "prod_sampler",
    name: "Sampler pack",
    description: "Mixed sample tin",
    sku: "SMP-01",
    price_cents: 2500,
    cost_cents: 900,
    supplier: "Mock Co",
    base_unit: "ea",
    stock_unit: "ea",
    sales_unit: "ea",
    quantity_base_milli: 12_000,
    quantity_in_stock: 12,
    unit: "ea",
    weight: 0,
    weight_unit: "g",
    image_path: "",
    sell_options: [],
    low_stock_threshold_milli: 3_000,
    updated_at: NOW,
  },
  {
    id: "prod_oz",
    name: "House blend",
    description: "Sold by weight",
    sku: "HB-OZ",
    price_cents: 400,
    cost_cents: 150,
    supplier: "Mock Co",
    base_unit: "g",
    stock_unit: "g",
    sales_unit: "oz",
    quantity_base_milli: 500_000,
    quantity_in_stock: 500,
    unit: "g",
    weight: 0,
    weight_unit: "g",
    image_path: "",
    sell_options: [
      { id: "opt_half", label: "1/2 oz", amount: 0.5, unit: "oz", price_cents: 1800 },
      { id: "opt_oz", label: "1 oz", amount: 1, unit: "oz", price_cents: 3200 },
    ],
    low_stock_threshold_milli: 50_000,
    updated_at: NOW,
  },
];

const mockCustomers: Customer[] = [
  {
    id: "cust_a",
    thread_id: THREAD_A,
    display_name: "Alex (mock)",
    notes: "Prefers quotes before confirm",
    updated_at: NOW,
  },
];

const mockOrders: Order[] = [
  {
    id: "ord_draft_1",
    customer_id: "cust_a",
    thread_id: THREAD_A,
    status: "draft",
    lines: [
      {
        product_id: "prod_sampler",
        name: "Sampler pack",
        quantity: 1,
        unit_price_cents: 2500,
        unit: "ea",
        line_total_cents: 2500,
      },
    ],
    total_cents: 2500,
    created_at: NOW - 50_000,
    updated_at: NOW - 50_000,
  },
];

const mockContacts: ContactMeta[] = [
  {
    contact_id: THREAD_A,
    display_name: "Alex (mock)",
    alias: "Alex",
    categories: [],
    favorite: true,
    muted: false,
    updated_at: NOW,
  },
];

const mockGroups: GroupMeta[] = [];

const mockOutbox: OutboxItem[] = [];

const mockDiagnostics: Diagnostics = {
  env_path: "/mock/.signalx.env",
  app_data_dir: "/mock/SignalX",
  signal_cli_path: "/usr/local/bin/signal-cli",
  signal_cli_version: "0.0.0-mock",
  signal_cli_usable: true,
  signal_cli_last_error: null,
  config_path: "/mock/.local/share/signal-cli",
  number: "+16172990756",
  active_account: "+16172990756",
  ollama_configured: false,
  ollama_url: "http://localhost:11434",
  ollama_model: null,
  ollama_reachable: false,
  ollama_last_error: "Browser preview — Ollama not available",
};

const mockReceive: ReceiveLoopState = {
  last_receive_ok_at: NOW - 5_000,
  last_receive_error: null,
  consecutive_failures: 0,
  backoff_ms: 0,
  cooldown_until: null,
};

const mockAi: AiStatus = {
  configured: false,
  ollama_url: "http://localhost:11434",
  ollama_model: null,
  ollama_reachable: false,
  ollama_last_error: null,
};

const mockAuto: AutoReplySettings = {
  enabled: false,
  allowlist: [],
  quiet_hours_start: null,
  quiet_hours_end: null,
  max_per_thread_per_hour: 3,
  max_per_window: 20,
  window_secs: 3600,
};

const mockIvrSettings: IvrSettings = {
  enabled: false,
  allowlist: [],
  require_allowlist: true,
  hide_zero_stock: true,
};

const mockIvrMenus: IvrMenus = {
  version: 3,
  entry: "main",
  session_ttl_ms: 900_000,
  nodes: {
    main: {
      prompt: "1 Catalog · 2 Order · 3 Status · 0 Human",
      choices: {
        "1": { action: "list_catalog", reply: "Here's the catalog." },
        "0": { action: "handoff", reply: "A person will take it from here." },
      },
      on_unknown: "Reply with a number from the menu.",
    },
  },
};

function ok<T>(data: T): ApiResult<T> {
  return { success: true, data };
}

function fail<T = never>(error: string): ApiResult<T> {
  return { success: false, error };
}

/** Handle Tauri command names with static fixtures. Mutations are in-memory only. */
export async function mockCall<T>(
  cmd: string,
  args?: Record<string, unknown>,
): Promise<ApiResult<T>> {
  switch (cmd) {
    case "cmd_get_threads":
      return ok(mockThreads as T);
    case "cmd_get_thread_messages": {
      const id = String(args?.threadId ?? "");
      return ok((mockMessages[id] ?? []) as T);
    }
    case "cmd_get_receive_loop_state":
      return ok(mockReceive as T);
    case "cmd_get_diagnostics":
      return ok(mockDiagnostics as T);
    case "cmd_set_signal_number": {
      const number = String(args?.number ?? "");
      mockDiagnostics.number = number;
      mockDiagnostics.active_account = number;
      return ok({
        number,
        env_path: mockDiagnostics.env_path,
        config_path: mockDiagnostics.config_path,
        restart_recommended: true,
      } as T);
    }
    case "cmd_list_signal_accounts":
      return ok({
        accounts: [mockDiagnostics.number],
        configured: mockDiagnostics.number,
        config_path: mockDiagnostics.config_path,
        stderr_hint: null,
      } as T);
    case "cmd_check_ai_status":
      return ok(mockAi as T);
    case "cmd_list_outbox":
      return ok(mockOutbox as T);
    case "cmd_get_outbox_state_summary":
      return ok({ queued: 0, sending: 0, failed: 0 } satisfies OutboxSummary as T);
    case "cmd_queue_outgoing_message":
    case "cmd_queue_outgoing_with_attachment": {
      const item: OutboxItem = {
        id: `out_${NOW}`,
        account_id: String(mockDiagnostics.number),
        thread_id: String(args?.threadId ?? THREAD_A),
        recipient: String(args?.recipient || args?.threadId || THREAD_A),
        content: String(args?.content ?? ""),
        created_at: Date.now(),
        attempt_count: 0,
        state: "queued",
      };
      mockOutbox.unshift(item);
      return ok(item as T);
    }
    case "cmd_retry_outbox_item":
    case "cmd_delete_outbox_item":
      return ok(true as T);
    case "cmd_mark_thread_read":
      return ok(true as T);
    case "cmd_search_messages": {
      const q = String(args?.query ?? "").toLowerCase();
      const hits: SearchResult[] = [];
      for (const msgs of Object.values(mockMessages)) {
        for (const m of msgs) {
          if (!q || m.content.toLowerCase().includes(q)) {
            hits.push({
              thread_id: m.thread_id,
              message_id: m.id,
              timestamp: m.timestamp,
              sender: m.sender,
              snippet: m.content.slice(0, 80),
            });
          }
        }
      }
      return ok(hits.slice(0, Number(args?.limit ?? 40)) as T);
    }
    case "cmd_list_contact_meta":
      return ok(mockContacts as T);
    case "cmd_set_contact_meta":
      return ok(mockContacts[0] as T);
    case "cmd_delete_contact_meta":
      return ok(true as T);
    case "cmd_list_group_meta":
      return ok(mockGroups as T);
    case "cmd_set_group_meta":
      return ok({
        group_id: String(args?.groupId ?? "g"),
        display_name: "Mock group",
        categories: [],
        favorite: false,
        muted: false,
        updated_at: NOW,
      } as T);
    case "cmd_create_signal_group":
      return fail("Mock preview — Signal group create requires Tauri");
    case "cmd_search_contacts":
    case "cmd_search_groups":
      return ok([] as T);
    case "cmd_summarize_thread":
      return ok("Mock summary: customer asked about sampler pack." as T);
    case "cmd_draft_reply":
      return ok("Sure — I can send a quote for the sampler pack." as T);
    case "cmd_suggest_thread_actions":
      return ok([
        { label: "Send quote", kind: "send_quote", payload: "ord_draft_1" },
      ] as T);
    case "cmd_get_pending_replies":
      return ok([] as T);
    case "cmd_export_thread":
    case "cmd_export_account":
      return ok({ path: "/mock/export.json" } as T);
    case "cmd_export_data_bundle":
      return ok({ path: "/mock/bundle.zip", bytes: 0, counts: { files: 0, attachments: 0 } } as T);
    case "cmd_import_data_bundle":
      return fail("Mock preview — import requires Tauri");
    case "cmd_open_path":
      return ok(true as T);
    case "cmd_get_auto_reply_settings":
      return ok(mockAuto as T);
    case "cmd_set_auto_reply_settings":
      return ok(((args?.settings as AutoReplySettings) ?? mockAuto) as T);
    case "cmd_list_auto_reply_audit":
      return ok([] as AutoReplyAuditEntry[] as T);
    case "cmd_set_thread_auto_reply":
      return ok({} as T);
    case "cmd_get_thread_auto_reply":
      return ok({
        thread_id: String(args?.threadId ?? ""),
        opted_in: false,
        on_allowlist: false,
        global_enabled: false,
        effective: false,
      } as T);
    case "cmd_get_ivr_settings":
      return ok(mockIvrSettings as T);
    case "cmd_set_ivr_settings":
      return ok(((args?.settings as IvrSettings) ?? mockIvrSettings) as T);
    case "cmd_get_ivr_menus":
    case "cmd_reset_ivr_menus":
      return ok(mockIvrMenus as T);
    case "cmd_set_ivr_menus":
      return ok(((args?.menus as IvrMenus) ?? mockIvrMenus) as T);
    case "cmd_preview_ivr_path":
      return ok([
        {
          input: "1",
          node_id: "main",
          reply: "Here's the catalog.",
          action: "list_catalog",
          handed_off: false,
          slots: {},
        },
      ] as T);
    case "cmd_get_thread_ivr":
    case "cmd_set_thread_ivr":
    case "cmd_clear_thread_handoff":
      return ok({
        thread_id: String(args?.threadId ?? ""),
        enabled: false,
        handed_off: false,
        node_id: "main",
        effective: false,
        global_enabled: false,
      } satisfies ThreadIvrStatus as T);
    case "cmd_list_products":
      return ok(mockProducts as T);
    case "cmd_upsert_product":
      return ok(((args?.product as Product) ?? mockProducts[0]) as T);
    case "cmd_delete_product":
      return ok({ deleted: true } as T);
    case "cmd_set_product_image":
    case "cmd_clear_product_image":
      return ok(mockProducts[0] as T);
    case "cmd_get_product_image":
      return fail("No mock image");
    case "cmd_adjust_product_stock":
      return ok(mockProducts[0] as T);
    case "cmd_export_products_csv":
      return ok({
        path: "/mock/products.csv",
        bytes: 32,
        csv: "id,name\nprod_sampler,Sampler pack\n",
      } as T);
    case "cmd_import_products_csv":
      return ok({ upserts: 0, creates: 0, errors: [], sample: [] } as T);
    case "cmd_list_customers":
      return ok(mockCustomers as T);
    case "cmd_upsert_customer":
      return ok(((args?.customer as Customer) ?? mockCustomers[0]) as T);
    case "cmd_delete_customer":
      return ok({ deleted: true } as T);
    case "cmd_ensure_customer_for_thread":
      return ok(mockCustomers[0] as T);
    case "cmd_list_orders": {
      const tid = args?.threadId as string | null | undefined;
      const list = tid ? mockOrders.filter((o) => o.thread_id === tid) : mockOrders;
      return ok(list as T);
    }
    case "cmd_create_order":
    case "cmd_update_draft_order_lines":
    case "cmd_confirm_order":
    case "cmd_duplicate_order_as_draft":
    case "cmd_set_order_status":
    case "cmd_send_order_invoice":
    case "cmd_send_order_quote":
      return ok(mockOrders[0] as T);
    case "cmd_list_commerce_audit":
      return ok([
        {
          id: "aud1",
          kind: "order.draft",
          summary: "Created draft for Sampler pack",
          order_id: "ord_draft_1",
          thread_id: THREAD_A,
          created_at: NOW - 40_000,
        },
      ] satisfies CommerceAuditEvent[] as T);
    case "cmd_sales_summary": {
      const summary: SalesSummary = {
        order_count: 1,
        revenue_cents: 0,
        by_status: [{ status: "draft", count: 1, total_cents: 2500 }],
        top_products: [
          {
            product_id: "prod_sampler",
            name: "Sampler pack",
            quantity: 1,
            revenue_cents: 0,
          },
        ],
        orders: mockOrders,
      };
      return ok(summary as T);
    }
    case "cmd_start_device_link":
      return fail("Mock preview — device link requires the Tauri desktop app");
    case "cmd_cancel_device_link":
      return ok({ cancelled: true } as T);
    default:
      return fail(`Mock preview — unhandled command: ${cmd}`);
  }
}

export async function mockOnEvent<T>(
  _event: string,
  _handler: (payload: T) => void,
): Promise<UnlistenFn> {
  return () => {};
}
